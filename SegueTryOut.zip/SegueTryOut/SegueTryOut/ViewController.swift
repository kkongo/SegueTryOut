//
//  ViewController.swift
//  SegueTryOut
//
//  Created by Kristjan Kongo on 18/07/2017.
//  Copyright © 2017 Kristjan Kongo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var textBox: UITextField!
    @IBOutlet weak var Button: UIButton!
    
    @IBAction func buttonPressed(_ sender: Any) {
        performSegue(withIdentifier: "sendDataForward", sender: self)
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("test")
       // if segue.identifier == "sendDataForward"{
         //   let secondVC = segue.destination as! SecondViewController
           // secondVC.toPass = textBox.text!

        //}
    }
}

