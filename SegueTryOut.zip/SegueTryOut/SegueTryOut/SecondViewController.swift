//
//  SecondViewController.swift
//  SegueTryOut
//
//  Created by Kristjan Kongo on 18/07/2017.
//  Copyright © 2017 Kristjan Kongo. All rights reserved.
//

import UIKit
class SecondViewController: UIViewController {
    var toPass : String!
    var data = "Hello"
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var textBo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Label.text = toPass
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton) {
    }
    
}
    
